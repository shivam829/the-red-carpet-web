import AdminPassesClient from "@/components/admin/AdminPassesClient";

export default function AdminPassesPage() {
  return <AdminPassesClient />;
}
